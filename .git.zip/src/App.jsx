
import RootRouter from './routes/root-routes'

const App = () => {
  return (
    <RootRouter />
  )
}

export default App