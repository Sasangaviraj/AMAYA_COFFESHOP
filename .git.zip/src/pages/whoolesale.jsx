import  Form  from "../components/form"

const WhooleSale = () => {
  return (
    <div className=" flex flex-col  items-center ">

      <section className="w-full h-auto relative z-0 overflow-hidden mb-12">
        <video
          className="w-full h-auto"
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
        >
          <source
            src="https://www.amayatheme.redsun.design/roastery/wp-content/uploads/sites/2/2021/02/amaya-video-1-xs.mp4"
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      </section>

      <div className="  w-[580px] gap-7 text-left">

        <div className="flex  flex-col items-center justify-center mt-12 gap-12 text-center">
          <h1 className="text-shop-p1 text-main-heading text-semibold font-playfair">
            Become a wholesale partner
          </h1>
          <p>
            Our wholesale program is all-inclusive and custom-made to your
            specific needs.
          </p>
          <p>
           We offer free local delivery, barista training, maintenance to your coffee equipment and beyond.
          </p>
        </div>
        
        <div className="flex flex-col gap-7 p-7">
            <h1 className="text-shop-p1 text-main-heading text-semibold font-playfair">
            Wholesale inquiry form
           </h1>

           <Form/>
        </div>
        
      </div>

    </div>
  );
};

export default WhooleSale;
