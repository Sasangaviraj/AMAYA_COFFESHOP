const Contact = () => {
  return (
    <div className=" p-20 gap-1">
      <div className="w-[1508px] p-5 border border-red-500 bg-gray-400 ">
        <p className=" text-black">shachini</p>
      </div>

      <div className="flex gap-1 pt-1">
        <div className="w-[500px] p-5 border border-red-500 bg-gray-400 ">
          <p className=" text-black">shachini</p>
        </div>

        <div className="w-[500px] p-5 border border-red-500 bg-gray-400 ">
          <p className=" text-black">shachini</p>
        </div>

        <div className="w-[500px] p-5 border border-red-500 bg-gray-400 ">
          <p className=" text-black">shachini</p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
