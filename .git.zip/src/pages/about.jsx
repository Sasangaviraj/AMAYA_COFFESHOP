import React from 'react'

const About = () => {
  return (
    <div>
        <div className="flex">
            <p className="p-5 border border-red-500 bg-gray-400 ">shachini</p>
            <p className="p-5 border border-red-500 bg-gray-400 ">shachini</p>
            <p className="p-5 border border-red-500 bg-gray-400 ">shachini</p>
            <p className="p-5 border border-red-500 bg-gray-400 ">shachini</p>
        </div>
    </div>
  )
}

export default About